#ifndef   SPOOKYSPACE_HPP
#define   SPOOKYSPACE_HPP

#include<string>
#include"Space.hpp"

class SpookySpace : public Space
{

  public:
	SpookySpace();
	void setDescription(std::string in);

};
#endif

