#ifndef   YARD_HPP
#define   YARD_HPP

#include<string>
#include"Space.hpp"

class Yard : public Space
{

  public:
  Yard();
	void setDescription(std::string in);

};
#endif

